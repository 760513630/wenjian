use edoc2v5

--  
-- 1 高版本   0 低版本
-- SELECT IF( EXISTS( select  table_name from information_schema.tables where table_name = 'mig_history'), 1, 0) as ecm


-- 查询ECM版本
-- 高版本
-- select  from edoc2v5.mig_history
-- select "product:",module_id,"version:",version from mig_history

-- 低版本
-- select * from __efmigrationshistory;
-- select "product:",max(MigrationId) from __efmigrationshistory;



-- 查询文件量
SELECT 
case table_name 
when 'dms_file' then 'File_Total:'  
when 'dms_filever' then 'File_Version_Total:'  
when 'dms_fileentityinfo' then 'File_Entity_Total:'  
when 'dms_filestorageinfo' then 'File_Storage_Total:'  
when 'dms_docpermission' then 'File_Permission_Total:'  
when 'dms_folder' then 'Folder_Total:'  
when 'org_user' then 'User_Total:' 
when 'org_group' then 'User_Group_Total:' 
when 'org_department' then 'Department_Total:' 
when 'org_position' then 'Position_Total:' 
when 'dms_custplan' then 'CustEvent_Plan_Total:' 
when 'dms_custevent' then 'CustEvent_Total:' 
when 'dms_cronplan' then 'Cron_Plan_Total:' 
when 'dms_folderupdater' then 'Folder_Updater_Total:' 
else table_name end 'Des'
,table_rows 'Total'
from  information_schema.tables 
where table_name in 
('dms_folder','dms_file','dms_filever','dms_fileentityinfo','dms_filestorageinfo','dms_docpermission','org_user','org_group','org_department','org_position','dms_custplan','dms_custevent','dms_cronplan','dms_folderupdater') and table_schema='edoc2v5';

-- 回收站文件数
select "FileRecyce:",count(1) from dms_file where file_state=8192;

-- 回收站文件夹数
select "FolderRecyce:",count(1) from dms_folder where folder_state=8192;

-- 查询每日活跃人数   
-- select CONCAT(date(online_loginTime),'Online_User:'),count(1)  'Total' from org_useronline group by date(online_loginTime);
select 'Online_User:',count(1)  'Total' from org_useronline  where  online_loginTime between CONCAT(curdate(),' 00:00:00') and  CONCAT(curdate(),' 23:59:59') group by date(online_loginTime);

-- 查询ppt水印策略
select 'ppt_Watermark_policy_Total:' ,count(1) as 'Total' from dms_folderwatermark where watermark_filetype ='.ppt|.pptx|.pps' and watermark_action >1;


-- 查询是否开启加解密
select  case cfg_name  when 'EncryptPolicy' then "Enable_Encryption_Policy:" else cfg_name end 'EncryptPolicy',
case cfg_value when '0' then "Close" when '1' then "Open" else cfg_name end 'Status:' 
from dms_instancecfg di   where cfg_name ='EncryptPolicy';

-- 查询是否开启杀毒
/*
select 
case cfg_name 
when 'EnableSecurityScan' then 'Enable_Security_Scan:' when 'enableClamAV' then 'Enable_Security_Scan:'  else cfg_name end 'des',
case cfg_value when 'False' then "Close"  when 'True' then "Open"  else cfg_name end 'Status' 
from dms_instancecfg di  where cfg_name ='EnableSecurityScan' or cfg_name ='enableClamAV';
*/
select 
case  when cfg_name ='EnableSecurityScan'  then 'Enable_Security_Scan:' when cfg_name ='UDCAntiVirusEnable' then 'Enable_Security_Scan:'  
else cfg_name end 'des', case cfg_value when 'False' then "Close" when 'True' then "Open"  else cfg_name end 'Status' 
from dms_instancecfg di  where (cfg_name ='EnableSecurityScan' or cfg_name ='UDCAntiVirusEnable') and cfg_value='True';



-- 文件转档
select case conv_state when '1' then 'File_Convert_Succeeded:' 
when '1024' then 'File_Convert_Error:' when '5000' then 'File_Convert_Wait:' 
when '5100' then 'File_Converting:' when '5200' then 'File_NoConvert:' 
when '5300' then 'File_Convert_First:' else conv_state end 'File_Convert', count(1) 'Total' 
from dms_fileConversion group by  conv_state;

-- 转档总数量
SELECT 
'File_Convert_Total:' 
,table_rows 'Total'
from  information_schema.tables 
where table_name='dms_fileConversion';

-- 缩略图转档
select case status when '1' then 'Thumbnail_Convert_Succeeded:' 
when '1024' then 'Thumbnail_Convert_Error:' when '5000' then 'Thumbnail_Convert_Wait:' 
when '5100' then 'Thumbnail_Converting:' when '5200' then 'Thumbnail_NoConvert:' 
when '5300' then 'Thumbnail_Convert_First:' else status end 'Thumbnail_Convert:', count(1) 'Total' 
from dms_thumbnailtask group by  status;

-- 待索引数量、索引异常数量、索引成功数量
select case file_indexstate when '0' then 'File_Index_Wait:' 
when '1' then 'File_Index_Fail:' when '2' then 'File_Index_Succeeded:' when '4' then 'File_Index_Error:' 
when '8' then 'File_NoIndex:'  
else file_indexstate end 'File_Index', count(1) 'Total' from dms_file group by  file_indexstate;

-- 索引总数量
SELECT 
'File_Index_Total:' 
,table_rows 'Total'
from  information_schema.tables 
where table_name='dms_file';

-- 是否开启主动转档
select case cfg_name when 'PassiveConvert' then "Enable_Passive_Convert:" else cfg_name end 'Enable_Passive_Convert',
case cfg_value when 'False' then "Close" 
when 'True' then "Open"  else cfg_name end 'Status' 
from dms_instancecfg di   where cfg_name ='PassiveConvert';

