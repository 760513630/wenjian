#!/bin/bash
#

log_info(){
   echo -e "[$(date +'%F %T')]: \033[32m $1 \033[0m"
}

log_error(){
   echo -e "[$(date +'%F %T')]: \033[31m $1 \033[0m"
}

log_file(){
   echo >&3 "[$(date +'%F %T')]: $1 "

}

log_warn(){
   echo -e "[$(date +'%F %T')]: \033[33m $1 \033[0m"
}


analyze_sys_env(){
    cpu_req=20
    mem_req=64000000
    is_minimal=$(cat $MetricsFile | awk -F'[ :]+' '/OS_MINIMAL/{print $2}')
    if [ "$is_minimal" != 'true' ]; then
         log_warn "黄色警告，操作系统非最小化安装，建议更换或联系运维关闭非必要进程。"
         log_file "黄色警告，操作系统非最小化安装，建议更换或联系运维关闭非必要进程。"
    fi

    total_mem=$(cat $MetricsFile | awk -F'[ :]+' '/MEMORY:/{print $2}')
    mem_used=$(cat $MetricsFile | awk -F'[ :%]+' '/MEMORY_USAGE:/{print $2}')
    cpu_core=$(cat $MetricsFile | awk -F':' '/CPU:/{print $2}')
    cpu_used=$(cat $MetricsFile | awk -F'[ :%]+' '/CPU_USAGE:/{print $2}')
    file_open=$(cat $MetricsFile | awk -F'[ :%]+' '/FILE_OPEN_VALID:/{print $2}')
    openfiles=$(cat $MetricsFile | awk -F'[ :%]+' '/FILE_MAX:/{print $2}')
    ipv4_forward=$(cat $MetricsFile | awk -F'[ :%]+' '/IPV4_FORWARD_VALID:/{print $2}')
    firewall_disabled=$(cat $MetricsFile | awk -F'[ :%]+' '/FIREWALL_DISABLED:/{print $2}')
    #cat $MetricsFile | grep IOPS_REQ | awk -F'[ :%]+' '/IOPS_REQ:/{print $2,$3}' | while read point req; do
    #     if [ "$req" != "true" ]; then
    #         iops=$(cat $MetricsFile | awk -F'[ :%]+' '/IOPS_TOTAL:/{print $2}')
    #         log_error "红色预警，存储挂载点: ${point}, 磁盘IOPS不满足标准要求6000以上（参考KM），需要项目经理联系客户更换。"
    #         log_file "红色预警，存储挂载点: ${point}, 磁盘IOPS不满足标准要求6000以上（参考KM），需要项目经理联系客户更换。"
    #     fi
    #done

    cat $MetricsFile | grep DISK_SPACE | awk -F'[ :%]+' '/DISK_SPACE:/{print $2,$3}' | while read point usage; do
         if [ "$usage" -ge 80 ]; then
              log_error "红色预警，存储路径$point，使用率${usage}%，建议加磁盘空间，使用空间需要保持低于70%，需要项目经理联系客户扩容。"
              log_file "红色预警，存储路径$point，使用率${usage}%，建议加磁盘空间，使用空间需要保持低于70%，需要项目经理联系客户扩容。"
         fi
    done


    if [ "$total_mem" -lt "$mem_req" ]; then
         log_warn "黄色预警，当前系统内存为$((total_mem/1000/1000))G，建议增加服务器内存至64G及以上，需要项目经理联系客户扩容。"
         log_file "黄色预警，当前系统内存为$((total_mem/1000/1000))G，建议增加服务器内存至64G及以上，需要项目经理联系客户扩容。"
    fi

    if [ "$cpu_core" -lt "$cpu_req" ]; then
         log_warn "黄色预警，当前系统cpu核心数为$cpu_core，建议增加服务器CPU核心数20C及以上，需要项目经理联系客户扩容。"
         log_file "黄色预警，当前系统cpu核心数为$cpu_core，建议增加服务器CPU核心数20C及以上，需要项目经理联系客户扩容。"
    fi

    if [ "$mem_used" -ge 80 -a "$mem_used" -lt 90 ]; then
        log_warn "黄色警告，当前系统内存使用率${mem_used}%，超过80%，转档、传输服务资源是否限制（参考KM），需要区域运维排查。"
        log_file "黄色警告，当前系统内存使用率${mem_used}%，超过80%，转档、传输服务资源是否限制（参考KM），需要区域运维排查。"
    elif [ "$mem_used" -ge 90 ]; then
        log_error "红色预警，当前系统内存使用率${mem_used}%，超过90%，转档、传输服务资源是否限制（参考KM），需要技术中心运维排查。"
        log_file "红色预警，当前系统内存使用率${mem_used}%，超过90%，转档、传输服务资源是否限制（参考KM），需要技术中心运维排查。"
    fi
    
    if [ "$file_open" != 'true' ]; then
       log_error "红色预警，当前最大文件打开数：${openfiles}，小于655360，需要调整最大打开文件数量（参考KM），需要区域运维排查。" 
       log_file "红色预警，当前最大文件打开数：${openfiles}，小于655360，需要调整最大打开文件数量（参考KM），需要区域运维排查。"
    fi

    if [ "$ipv4_forward" != 'true' ]; then
        log_error "红色预警，需要开启IPV4转发（参考KM），需要区域运维排查。"
        log_file "红色预警，需要开启IPV4转发（参考KM），需要区域运维排查。"
    fi

    if [ "$firewall_disabled" != 'true' ]; then
        log_warn "黄色预警，需要关闭或者新增策略（参考KM），需要区域运维排查。"
        log_file "黄色预警，需要关闭或者新增策略（参考KM），需要区域运维排查。"
    fi

}

analyze_middleware(){
    mysql_connections=$(cat $MetricsFile | awk -F'[ :]+' '/MYSQL_CONS:/{print $2}')
    binlog_on=$(cat $MetricsFile | awk -F'[ :]+' '/MYSQL_BINLOG:/{print $2}')
    slowlog_on=$(cat $MetricsFile | awk -F'[ :]+' '/MYSQL_SLOWLOG:/{print $2}')
    redis_connections=$(cat $MetricsFile | awk -F'[ :]+' '/REDIS_CONS:/{print $2}')
    if [ -n "$mysql_connections" ]; then
        if [ "$mysql_connections" -ge 2000 ]; then
            log_error "红色预警，mysql链接数超过2000，需要技术中心运维和研发排查。"
            log_file "红色预警，mysql链接数超过2000，需要技术中心运维和研发排查。"
        fi
    fi

    if [ -n "$binlog_on" ]; then
        if [ "$binlog_on" != on ]; then
            log_warn "黄色预警，mysql二进制日志未开启，请联系区域运维和客户开启。"
            log_file "黄色预警，mysql二进制日志未开启，请联系区域运维和客户开启。"
        fi
    fi

    if [ -n "$slowlog_on" ]; then
        if [ "$slowlog_on" != on ]; then
            log_warn "红色预警，mysql慢查询日志未开启，请联系区域运维和客户开启。"
            log_file "红色预警，mysql慢查询日志未开启，请联系区域运维和客户开启。"
        fi 
    fi 

    if [ $(cat $MetricsFile | grep -c MQ_BLOCK_QUEUE) -ne 0 ]; then
        log_error "红色预警，rabbitmq消息堆积超过10000，需要技术中心运维和研发排查。"
        log_file "红色预警，rabbitmq消息堆积超过10000，需要技术中心运维和研发排查。"
    fi 

    if [ -n "$redis_connections" ]; then
        if [ "$redis_connections" -ge 8000 ]; then
            log_error "红色预警，redis连接数超过8000，需要技术中心运维和研发排查。" 
            log_file "红色预警，redis连接数超过8000，需要技术中心运维和研发排查。" 
        fi
    fi

    es_index_count=$(cat $MetricsFile | grep ES_INDEX_COUNT | egrep 'filelog_.+' | awk -F'[ :]+' '{print $NF}')
    if [ -n "$es_index_count" ]; then
        if [ "$es_index_count" -ge 50000000 ]; then
             log_warn "黄色预警，定期执行日志归档，需要项目经理与客户确认。"
             log_file "黄色预警，定期执行日志归档，需要项目经理与客户确认。"
        fi
    fi

    es_total_size=$(cat $MetricsFile | awk -F'[ :]+' '/ES_TOTAL_SIZE_KB:/{print $2}')
    if [ -n "$es_total_size" ]; then
        if [ "$es_total_size" -ge 524288000 ]; then
             log_error "红色预警，ES索引优化（参考KM），需要技术中心运维和研发排查。"
             log_file "红色预警，ES索引优化（参考KM），需要技术中心运维和研发排查。"
        fi
    fi

}

get_env(){
    userGroup=$(cat $MetricsFile | awk -F'[ \t:]+' '/User_Group_Total:/{print $2}')
    ecm_ver=$(cat $MetricsFile | awk -F'[ \t:]+' '/PRODUCT:/{
                                                        if($2~/edoc2/){
                                                           print $NF
                                                        }else if($2~/lower_ecm/){
                                                           sub("[0-9]+?_v","",$NF)
                                                           print $NF   
                                                      }
    }')

    File_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Total:/{print $2}')
    File_Version_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Version_Total:/{print $2}')
    File_Permission_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Permission_Total:/{print $2}')
    weboffice_ver=$(cat $MetricsFile | awk -F'[ \t:]+' '/WEBOFFICE_VER:/{print $2}') 
    edoc2_ver=${ecm_ver//./}
    CustEvent_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/CustEvent_Total:/{print $2}')
    Cron_Plan_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Cron_Plan_Total:/{print $2}')
    ppt_Watermark_policy_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/ppt_Watermark_policy_Total:/{print $2}')
    Enable_Passive_Convert=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Enable_Passive_Convert:/{print $2}')
    File_Convert_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Convert_Total:/{print  $2}')
    File_Convert_Error=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Convert_Error:/{print  $2}')
    File_Convert_Succeeded=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Convert_Succeeded:/{print  $2}')
    File_Convert_Wait=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Convert_Wait:/{print  $2}')
    File_Index_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Index_Total:/{print $2}')
    File_Index_Error=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Index_Error:/{print $2}')
    File_Index_Wait=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Index_Wait:/{print $2}')
    File_Index_Succeeded=$(cat $MetricsFile | awk -F'[ \t:]+' '/File_Index_Succeeded:/{print $2}')
    User_Total=$(cat $MetricsFile | awk -F'[ \t:]+' '/User_Total:/{print $2}')
    lic_MmaxUser=$(cat $MetricsFile | awk -F'[ \t:]+' '/LIC_MAXUSER:/{print $2}')
    lic_exp_time=$(cat $MetricsFile | awk -F'[ \t:]+' '/LIC_EXP_TIME:/{print $2}')
    lic_near_exp=$(cat $MetricsFile | awk -F'[ \t:]+' '/LIC_NEAR_EXP:/{print $2}')
    online_user=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Online_User:/{print $NF}')
    Enable_Security_Scan=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Enable_Security_Scan:/{print $NF}')
    Enable_Encryption_Policy=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Enable_Encryption_Policy:/{print $NF}')
    Folder_Updater_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Folder_Updater_Total:/{print $NF}')
    File_Permission_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/File_Permission_Total:/{print $NF}')
    File_Storage_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/File_Storage_Total:/{print $NF}')
    File_Entity_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/File_Entity_Total:/{print $NF}')
    Folder_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Folder_Total:/{print $NF}')
    FileRecyce=$(cat $MetricsFile | awk  -F'[ \t:]+' '/FileRecyce:/{print $NF}')
    FolderRecyce=$(cat $MetricsFile | awk  -F'[ \t:]+' '/FolderRecyce:/{print $NF}')
    #待计算文件夹大小数量
    Folder_Updater_Total=$(cat $MetricsFile | awk  -F'[ \t:]+' '/Folder_Updater_Total:/{print $NF}')
    edoc2_counts=$(cat $MetricsFile | awk  -F'[ :]+' '/edoc2_counts:/{print $NF}')

}


print_tables_size(){
   
   declare -A tb_size
   tb_size=(
   [dms_file]="$File_Total"
   [dms_filever]="$File_Version_Total"
   [dms_fileentityinfo]="$File_Entity_Total"
   [dms_filestorageinfo]="$File_Storage_Total"
   [dms_docpermission]="$File_Permission_Total"
   [dms_folder]="$Folder_Total"
   [org_group]="$userGroup"
   [org_user]="$User_Total"
   [dms_custevent]="$CustEvent_Total"
   [dms_cronplan]="$Cron_Plan_Total"
   [dms_folderupdater]="$Folder_Updater_Total"
   [org_useronline]="$online_user"
   [dms_folderwatermark]="$ppt_Watermark_policy_Total"
   [Enable_Encryption_Policy]="$Enable_Encryption_Policy"
   [EnableSecurityScan]="${Enable_Security_Scan:-Close}"
   [Enable_Passive_Convert]="$Enable_Passive_Convert"
   [File_Convert_Wait]="$File_Convert_Wait"
   [File_Index_Error]="$File_Index_Error"
   [File_Convert_Succeeded]="$File_Convert_Succeeded"
   [File_Index_Wait]="$File_Index_Wait"
   [File_Index_Error]="$File_Index_Error"
   [File_Index_Succeeded]="$File_Index_Succeeded"
   )
   declare -A tb_map
   tb_map=(
   [dms_file]="文件数量:"
   [dms_filever]="文件版本数量:"
   [dms_fileentityinfo]="文件实体数量:"
   [dms_filestorageinfo]="文件存储数量:"
   [dms_docpermission]="权限数量:"
   [dms_folder]="文件夹数量:"
   [org_group]="用户组数量:"
   [org_user]="总用户数:"
   [dms_custevent]="主动事件数:"
   [dms_cronplan]="计划任务数:"
   [dms_folderupdater]="待计算文件夹大小数量:"
   [org_useronline]="活跃用户数:"
   [dms_folderwatermark]="ppt水印策略数:"
   [Enable_Encryption_Policy]="是否开启加解密:"
   [EnableSecurityScan]="是否开启杀毒:"
   [Enable_Passive_Convert]="是否开启被动转档:"
   [File_Convert_Wait]="待转档文件数:"
   [File_Index_Error]="索引异常数:"
   [File_Convert_Succeeded]="转档成功数:"
   [File_Index_Wait]="待索引数:"
   [File_Index_Error]="索引异常数:"
   [File_Index_Succeeded]="索引成功数:"
   ) 
  

   for t in ${!tb_size[@]}; do
       if [ -n "${tb_size[$t]}" ]; then
           log_info "${tb_map[$t]} ${tb_size[$t]}"
           log_file "${tb_map[$t]} ${tb_size[$t]}"
       fi
   done 

}


business_analysis(){

    if [ -n "$edoc2_ver" ]; then
        log_info "ECM版本：$edoc2_ver。"
        log_file "ECM版本：$edoc2_ver。"
    fi

    if [ -n "$edoc2_counts" ]; then
        if [[ "$edoc2_counts" -ge 2 ]]; then
              log_info "ECM为集群环境。"
              log_file "ECM为集群环境。"
        else 
              log_info "ECM为单机环境。"
              log_file "ECM为单机环境。"
        fi
    fi
    
    if [ -n "$userGroup" ]; then
        if [[ "$userGroup" -ge 1000 ]]; then
            log_error "红色预警，当前版本$ecm_ver，用户组超过1000，6.3以下版本需要程序优化。"
            log_file "红色预警，当前版本$ecm_ver，用户组超过1000，6.3以下版本需要程序优化。"
        fi
    fi

    if [ -n "$User_Total" -a -n "$lic_MmaxUser" ]; then
         user_percent=$(awk 'BEGIN{print int('"$User_Total"'/'"$lic_MmaxUser"'*100)}')
         if [ "$user_percent" -ge 90 ]; then
               log_warn "黄色预警，Lic用户数: ${lic_MmaxUser}，使用量超过90%，剩余用户数不足，需要项目经理与客户确认。"
               log_file "黄色预警，Lic用户数: ${lic_MmaxUser}，使用量超过90%，剩余用户数不足，需要项目经理与客户确认。"
         fi
    fi

    #if [ -n "$lic_exp_time" -a -n "$lic_near_exp" ]; then
    #     log_warn "黄色预警，Lic过期时间小于30天，需要项目经理及时申请。"
    #     log_file "黄色预警，Lic过期时间小于30天，需要项目经理及时申请。"
    #fi
    
    if [ -n "$File_Total" ]; then
         if [ "$File_Total" -ge 100000000 ]; then
             log_warn "黄色预警，文件量: $File_Total，文件量超过1亿，6.3以下版本需要程序优化。"
             log_file "黄色预警，文件量: $File_Total，文件量超过1亿，6.3以下版本需要程序优化。"
         fi
    fi
    if [ -n "$File_Version_Total" ]; then
         if [ "$File_Version_Total" -ge 100000000 ]; then
              log_warn "黄色预警，文件版本量: $File_Version_Total，文件版本量超过1亿，6.3以下版本需要程序优化。"
              log_file "黄色预警，文件版本量: $File_Version_Total，文件版本量超过1亿，6.3以下版本需要程序优化。"
         fi
    fi

    if [ -n "$File_Permission_Total" ]; then
          if [ "$File_Permission_Total" -ge 100000 ]; then
                log_error "红色预警，权限量: $File_Permission_Total，需要技术中心运维和研发排查。"
                log_file "红色预警，权限量: $File_Permission_Total，需要技术中心运维和研发排查。"
          fi
    fi

    if [ -n "$CustEvent_Total" ]; then
          if [ "$CustEvent_Total" -ge 200 ]; then
                log_error "红色预警，主动事件数超过200，需要技术中心运维和研发排查。"
                log_file "红色预警，主动事件数超过200，需要技术中心运维和研发排查。"
          fi
    fi

    if [ -n "$Cron_Plan_Total" ]; then
          if [ "$Cron_Plan_Total" -ge 200 ]; then
               log_error "红色预警，定时任务数超过200，需要技术中心运维和研发排查。"
               log_file "红色预警，定时任务数超过200，需要技术中心运维和研发排查。"
          fi
    fi

    if [ -n "$ppt_Watermark_policy_Total" ]; then
         if [ "$ppt_Watermark_policy_Total" -gt 0 ]; then
                log_error "红色预警，6.3以下版本需要程序优化ppt水印策略。"
                log_file "红色预警，6.3以下版本需要程序优化ppt水印策略。"
         fi
    fi

    if [ -n "$Enable_Passive_Convert" ]; then
         if [ "$Enable_Passive_Convert" != "Open" ]; then
               log_warn "黄色预警，关闭主动转档，需要项目经理与客户确认。"
               log_file "黄色预警，关闭主动转档，需要项目经理与客户确认。"
         fi
    fi
   
    if [ -n "$weboffice_ver" ]; then
        if [ "$weboffice_ver" == "7.1.1" ]; then
            log_warn "黄色预警，weboffice版本为${weboffice_ver}，6.3以下版本需要程序优化。"
            log_file "黄色预警，weboffice版本为${weboffice_ver}，6.3以下版本需要程序优化。"
        fi
    fi
  
    if [ -n "$File_Convert_Total" -a -n "$File_Convert_Error" ]; then
        conv_error_percent=$(awk 'BEGIN{print int('"$File_Convert_Error"'/'"$File_Convert_Total"'*100)}')
        if [ "$conv_error_percent" -ge 10 ]; then
            log_warn "黄色预警，转档异常数量超过总量10%，需要技术中心运维和研发排查。"
            log_file "黄色预警，转档异常数量超过总量10%，需要技术中心运维和研发排查。"
        fi
    fi

    if [ -n "$File_Index_Total" -a -n "$File_Index_Error" ]; then
         index_error_percent=$(awk 'BEGIN{print int('"$File_Index_Error"'/'"$File_Index_Total"'*100)}')
         if [ "$index_error_percent" -ge 10 ]; then
              log_warn "黄色预警，索引异常数量超过总量10%，需要技术中心运维和研发排查。"
              log_file "黄色预警，索引异常数量超过总量10%，需要技术中心运维和研发排查。"
         fi
    fi


    if [ -n "$FolderRecyce" -a -n "$FileRecyce" ]; then
         if [ "$((FolderRecyce+FileRecyce))" -gt 1000000 ]; then
              log_error "红色预警，回收站数据超过100W，6.3以下版本需要程序优化。"
              log_file "红色预警，回收站数据超过100W，6.3以下版本需要程序优化。"
         fi
    fi

    if [ -n "$Folder_Updater_Total" ]; then
         if [ "$Folder_Updater_Total" -gt 1000 ]; then
              log_error "红色预警，大小计算表记录超过1000，6.3以下版本需要程序优化。"
              log_file "红色预警，大小计算表记录超过1000，6.3以下版本需要程序优化。"
         fi
    fi
}

scene_analysis(){
    edoc2_counts=$(cat $MetricsFile | awk '/edoc2_counts:/{print $2}') 
    online_user=${online_user:-0}
    if [[ "$lic_MmaxUser" -le 500 ]]; then
        if [ "$cpu_core" -lt 20 ]; then
              log_warn "黄色预警，cpu不满足单机部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "黄色预警，cpu不满足单机部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi
    
        if [ "$total_mem" -lt 64000000 ]; then
              log_warn "黄色预警，内存不满足单机部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "黄色预警，内存不满足单机部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi

        if [[ "$File_Total" -ge 50000000 ]] && [[ "$online_user" -ge 300 ]]; then
              log_warn "黄色预警，文件量超50000000，建议切换集群架构，需要区域运维优化部署架构。"
              log_file "黄色预警，文件量超50000000，建议切换集群架构，需要区域运维优化部署架构。"
        fi
    elif [[ "$lic_MmaxUser" -gt 500 ]] && [[ "$lic_MmaxUser" -le 1000 ]]; then
        if [[ "$edoc2_counts" -lt 3 ]]; then
              log_warn "黄色预警，edoc2服务数小于3，不满足中型集群部署标准（参考服务器配置建议），需要区域运维优化部署架构。"
              log_file "黄色预警，edoc2服务数小于3，不满足中型集群部署标准（参考服务器配置建议），需要区域运维优化部署架构。"
        fi

        if [ "$cpu_core" -lt 20 ]; then
              log_warn "黄色预警，lic用户数：$lic_MmaxUser，cpu不满足中型部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "黄色预警，lic用户数：$lic_MmaxUser，cpu不满足中型部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi
    
        if [ "$total_mem" -lt 64000000 ]; then
              log_warn "黄色预警，lic用户数：$lic_MmaxUser，内存不满足中型部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "黄色预警，lic用户数：$lic_MmaxUser，内存不满足中型部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi
   
        if [ "$is_ecm" == "true" ]; then 
            if [ "$is_mid" == "true" -o "$is_ceph" == "true" ]; then
                log_warn "黄色预警，不满足中型集群部署标准，ceph或中间件与应用部署同一台，需要区域运维优化部署架构。"
                log_file "黄色预警，不满足中型集群部署标准，ceph或中间件与应用部署同一台，需要区域运维优化部署架构。"
            fi
        fi

        if [[ "$File_Total" -ge 80000000 ]] && [[ "$online_user" -ge 800 ]]; then
              log_warn "黄色预警，文件量超80000000，建议切换大型集群架构，需要区域运维优化部署架构。"
              log_file "黄色预警，文件量超80000000，建议切换大型集群架构，需要区域运维优化部署架构。"
        fi
    elif [[ "$lic_MmaxUser" -gt 1000 ]] && [[ "$lic_MmaxUser" -le 5000 ]]; then
        if [[ "$edoc2_counts" -lt 3 ]]; then
              log_warn "黄色预警，edoc2服务数小于3，不满足大型集群部署标准（参考服务器配置建议），需要区域运维优化部署架构。"
              log_file "黄色预警，edoc2服务数小于3，不满足大型集群部署标准（参考服务器配置建议），需要区域运维优化部署架构。"
        fi
        
        if [ "$cpu_core" -lt 40 ]; then
              log_error "红色预警，lic用户数：$lic_MmaxUser，cpu不满足大型集群部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "红色预警，lic用户数：$lic_MmaxUser，cpu不满足大型集群部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi

        if [ "$total_mem" -lt 128000000 ]; then
              log_error "红色预警，lic用户数：$lic_MmaxUser，内存不满足大型集群部署标准（参考服务器配置建议），需要区域运维扩容。"
              log_file "红色预警，lic用户数：$lic_MmaxUser，内存不满足大型集群部署标准（参考服务器配置建议），需要区域运维扩容。"
        fi

        if [ "$is_ecm" == "true" ]; then
            if [ "$is_mid" == "true" -o "$is_ceph" == "true" ]; then
                log_error "红色预警，不满足大型集群部署标准，ceph或中间件与应用部署同一台，需要区域运维优化部署架构。"
                log_file "红色预警，不满足大型集群部署标准，ceph或中间件与应用部署同一台，需要区域运维优化部署架构。"
            fi
        fi

        if [[ "$File_Total" -ge 100000000 ]] && [[ "$online_user" -ge 3000 ]]; then
              log_warn "色预警警，文件量超100000000，建议切换超大型集群架构，需要区域运维优化部署架构。"
              log_file "黄色预警，文件量超100000000，建议切换超大型集群架构，需要区域运维优化部署架构。"
        fi
     elif [[ "$lic_MmaxUser" -gt 5000 ]]; then
        log_warn "黄色预警，用户数超5000，建议使用定制架构，请联系技术支持中心。"
        log_file "黄色预警，用户数超5000，建议使用定制架构，请联系技术支持中心。"
    fi


}

analyze_application(){
    cat $MetricsFile | grep MEM_LIMIT &> /dev/null
    if [ $? -eq 0 ]; then
        cat $MetricsFile | grep MEM_LIMIT | awk -F'[ :]+' '{print $2,$3}' | while read name limit; do
             if [ "$limit" != "true" ]; then
                 if [ "$name" == "content" ]; then
                     log_warn "黄色预警，请确认${name}服务是否设置内存限制（限制内存8G,参考KM），需要区域运维排查。"
                     log_file "黄色预警，请确认${name}服务是否设置内存限制（限制内存8G，参考KM），需要区域运维排查。"
                 else
                     log_warn "黄色预警，请确认${name}服务是否设置内存限制（总内存30%,参考KM），需要区域运维排查。"
                     log_file "黄色预警，请确认${name}服务是否设置内存限制（总内存30%，参考KM），需要区域运维排查。"
                 fi

             fi
        done
    fi

    edoc2_thread=$(cat $MetricsFile | awk -F'[ :]+' '/EDOC2_THREADS:/{print $2}')
    if [ -n "$edoc2_thread" ]; then
        if [ "$edoc2_thread" -ge 1000 ]; then
             log_error "红色预警，edoc2线程数过高，需要技术中心运维和研发排查。"
             log_file "红色预警，edoc2线程数过高，需要技术中心运维和研发排查。"
        fi
    fi

    if [ "$(cat $MetricsFile | awk -F'[ :]+' '/EDOC2_IS_RESTART:/{print $2}')" == "true" ]; then
         log_warn "黄色预警，edoc2服务七天内发生重启，需要技术中心运维和研发排查。"
         log_file "黄色预警，edoc2服务七天内发生重启，需要技术中心运维和研发排查。"
    fi

    cat $MetricsFile | grep SVC_COUNT_VALID &> /dev/null
    if [ $? -eq 0 ]; then
        cat $MetricsFile | grep SVC_COUNT_VALID | awk -F'[ :]+' '{print $2,$3}' | while read svc valid; do
             if [ "$valid" != "true" ]; then
                   log_error "红色预警，服务${svc}与实际运行数量不一致，需要技术中心运维和研发排查。"
                   log_file "红色预警，服务${svc}与实际运行数量不一致，需要技术中心运维和研发排查。"
             fi
        done
    fi

    if [ "$is_ecm" == "true" -a "$is_mid" == "true" ]; then
         log_warn "黄色预警，中间件和应用在同一台服务器，可能导致负载过高，需要项目经理联系客户更换。"
         log_file "黄色预警，中间件和应用在同一台服务器，可能导致负载过高，需要项目经理联系客户更换。"
    fi


}



main(){
    MetricsFile=$1
    if [ ! -f "$MetricsFile" ]; then
        echo "usage: bash $1 /path/to/metrics.txt"
        exit 10
    fi
    path=$(dirname $1)
    exec 3>> $path/system-check-$(date +%F).log
    is_ecm=$(cat $MetricsFile | awk -F'[ :]+' '/IS_ECM:/{print $2}')
    is_mid=$(cat $MetricsFile | awk -F'[ :]+' '/IS_MIDDWARE:/{print $2}')
    is_ceph=$(cat $MetricsFile | awk -F'[ :]+' '/IS_CEPH:/{print $2}')
    analyze_sys_env
    analyze_middleware
    analyze_application
    get_env
    if [ "$is_mid" == "true" ]; then
        print_tables_size
    fi
    business_analysis
    scene_analysis
}

main $1
